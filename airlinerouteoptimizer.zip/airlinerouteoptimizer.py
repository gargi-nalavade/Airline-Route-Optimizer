import heapq
from datetime import datetime, timedelta
from typing import List, Dict, Callable, Tuple
import tkinter as tk
from tkinter import ttk, messagebox
import random

# -------------------------------------------------
# Data Models
# -------------------------------------------------
class Flight:
    def __init__(self, origin: str, destination: str, depart: datetime, arrive: datetime,
                 price: float, seats_available: int, is_peak_hour: bool = False, airline: str = "Skyline Airways"):
        self.origin = origin
        self.destination = destination
        self.depart = depart
        self.arrive = arrive
        self.price = price
        self.seats_available = seats_available
        self.is_peak_hour = is_peak_hour
        self.airline = airline


class AirlineGraph:
    def __init__(self):
        self.adj_list: Dict[str, List[Flight]] = {}

    def add_flight(self, flight: Flight):
        self.adj_list.setdefault(flight.origin, []).append(flight)

    def get_outgoing(self, city: str) -> List[Flight]:
        return self.adj_list.get(city, [])


# -------------------------------------------------
# Route Search (Uniform-cost with constraints)
# -------------------------------------------------
def find_all_routes(graph: AirlineGraph, origin: str, destination: str, start_after: datetime,
                    weight_fn: Callable[[Flight], float], time_fn: Callable[[Flight], float],
                    min_layover: timedelta = timedelta(minutes=30),
                    max_layover: timedelta = timedelta(hours=8),
                    require_seats: bool = False, min_seats: int = 1, max_connections: int = 5,
                    limit: int = 10) -> List[Tuple[float, float, List[Flight]]]:

    pq = []
    counter = 0
    heapq.heappush(pq, (0.0, counter, start_after, 0, origin, [], 0.0))
    visited = {}
    results = []

    while pq and len(results) < limit:
        cum_weight, _, arrival_time, connections, city, path, total_time = heapq.heappop(pq)
        if connections > max_connections:
            continue
        if city == destination and path:
            results.append((cum_weight, total_time, path))
            continue

        key = (city, connections, arrival_time)
        if key in visited and visited[key] <= cum_weight:
            continue
        visited[key] = cum_weight

        for flight in graph.get_outgoing(city):
            if require_seats and flight.seats_available < min_seats:
                continue
            if not path:
                if flight.depart < start_after:
                    continue
            else:
                layover = flight.depart - arrival_time
                if layover < min_layover or layover > max_layover:
                    continue
                if flight.depart < arrival_time:
                    continue

            w = weight_fn(flight)
            travel_time = time_fn(flight)
            counter += 1
            heapq.heappush(pq, (
                cum_weight + w, counter, flight.arrive, connections + 1,
                flight.destination, path + [flight], total_time + travel_time))

    return results


def price_with_peak(f: Flight) -> float:
    return f.price * (1.2 if f.is_peak_hour else 1.0)


def flight_duration(f: Flight) -> float:
    return (f.arrive - f.depart).total_seconds() / 3600.0


# -------------------------------------------------
# UI Helpers
# -------------------------------------------------
AIRLINE_COLORS = ["#0F62FE", "#8A3FFC", "#1192E8", "#24A148", "#FF832B", "#DA1E28"]
AIRLINES = [
    ("Skyline Airways", "✈"),
    ("Nimbus Air", "☁"),
    ("Aurora Jet", "🛩"),
    ("Indigo Wing", "💙"),
    ("Sunrise Air", "🌅"),
    ("Pulse Airlines", "⚡")
]

STATUS_BG = {
    "GOOD": "#E8F5E9",
    "WARN": "#FFF8E1",
    "BAD": "#FFEBEE"
}
STATUS_FG = {
    "GOOD": "#1B5E20",
    "WARN": "#8D6E63",
    "BAD": "#B71C1C"
}


# -------------------------------------------------
# Main App
# -------------------------------------------------
class FlightBookingApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Skyline • Flight Booking")
        self.root.geometry("1040x760")
        self.root.configure(bg="#F2F6FB")

        # ttk theme
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure("TButton", font=("Segoe UI", 11, "bold"), padding=10)
        style.configure("TRadiobutton", background="#F2F6FB", font=("Segoe UI", 10))
        style.configure("TCheckbutton", background="#F2F6FB", font=("Segoe UI", 10))
        style.configure("Card.TFrame", background="white", relief="ridge")

        self.graph = AirlineGraph()
        self.routes = []
        self._seed_sample_data()
        self._build_header()
        self._build_search()
        self._build_results_area()

    # ---------- UI Layout ----------
    def _build_header(self):
        header = tk.Frame(self.root, bg="#0F62FE")
        header.pack(fill="x")
        tk.Label(header, text="✈ Skyline Booking", font=("Segoe UI", 22, "bold"), fg="white", bg="#0F62FE", pady=16).pack(side="left", padx=20)

    def _build_search(self):
        wrap = tk.Frame(self.root, bg="#F2F6FB")
        wrap.pack(fill="x", padx=20, pady=16)
        card = tk.Frame(wrap, bg="white", bd=0, highlightthickness=1, highlightbackground="#E1E8F5")
        card.pack(fill="x")

        inner = tk.Frame(card, bg="white", padx=16, pady=12)
        inner.pack(fill="x")

        self.origin_entry = self._labeled_entry(inner, "Origin", 0, "Mumbai")
        self.dest_entry = self._labeled_entry(inner, "Destination", 1, "Delhi")
        self.time_entry = self._labeled_entry(inner, "Earliest Hour (0-23)", 2, "6")

        self.sort_var = tk.StringVar(value="price")
        ttk.Radiobutton(inner, text="💰 Cheapest", variable=self.sort_var, value="price").grid(row=0, column=3)
        ttk.Radiobutton(inner, text="⏱ Fastest", variable=self.sort_var, value="time").grid(row=1, column=3)

        self.require_seats = tk.BooleanVar(value=True)
        ttk.Checkbutton(inner, text="Only show available seats", variable=self.require_seats).grid(row=2, column=3)

        self.seats_entry = self._labeled_entry(inner, "Min Seats", 3, "1")
        self.conn_entry = self._labeled_entry(inner, "Max Connections", 4, "3")

        ttk.Button(inner, text="🔍 Search Flights", command=self.search_routes).grid(row=5, column=3, sticky="e")

    def _build_results_area(self):
        self.results_frame = tk.Frame(self.root, bg="#F2F6FB")
        self.results_frame.pack(fill="both", expand=True)
        self._empty_state()

    def _labeled_entry(self, parent, label, row, placeholder="", width=18):
        frame = tk.Frame(parent, bg="white")
        frame.grid(row=row, column=0, padx=12, pady=6, sticky="w")
        tk.Label(frame, text=label, bg="white", fg="#334", font=("Segoe UI", 10, "bold")).pack(anchor="w")
        e = tk.Entry(frame, font=("Segoe UI", 11), width=width)
        e.pack()
        e.insert(0, placeholder)
        return e

    def _empty_state(self):
        for w in self.results_frame.winfo_children():
            w.destroy()
        tk.Label(self.results_frame, text="Start your journey ✈", font=("Segoe UI", 16, "bold"), bg="#F2F6FB").pack(pady=40)

    # ---------- Search ----------
    def search_routes(self):
        origin = self.origin_entry.get().strip()
        dest = self.dest_entry.get().strip()
        try:
            hour = int(self.time_entry.get())
        except Exception:
            messagebox.showerror("Invalid Time", "Enter an hour between 0 and 23.")
            return

        t = datetime(2025, 8, 15).replace(hour=hour)
        require_seats = self.require_seats.get()
        try:
            min_seats = int(self.seats_entry.get()) if require_seats else 1
            max_conn = int(self.conn_entry.get())
        except Exception:
            messagebox.showerror("Invalid Input", "Enter valid numbers for seats and connections.")
            return

        routes = find_all_routes(
            self.graph, origin, dest, t, price_with_peak, flight_duration,
            require_seats=require_seats, min_seats=min_seats,
            max_connections=max_conn, limit=20
        )

        routes.sort(key=lambda x: x[0] if self.sort_var.get() == "price" else x[1])
        self.routes = routes

        for w in self.results_frame.winfo_children():
            w.destroy()

        if not routes:
            tk.Label(self.results_frame, text="No routes found 😢", font=("Segoe UI", 14), bg="#F2F6FB").pack(pady=40)
            return

        for idx, (cost, hours, flights) in enumerate(routes, 1):
            self._render_ticket(idx, cost, hours, flights)

    def _render_ticket(self, idx, cost, hours, flights):
        card = tk.Frame(self.results_frame, bg="white", padx=10, pady=10, relief="ridge")
        card.pack(fill="x", padx=20, pady=10)

        airline, icon = random.choice(AIRLINES)
        tk.Label(card, text=f"{icon} {airline}", font=("Segoe UI", 14, "bold"), bg="white").pack(anchor="w")
        tk.Label(card, text=f"₹ {round(cost):,} • {round(hours, 1)} hrs", font=("Segoe UI", 12), bg="white", fg="#333").pack(anchor="w")
        route = " → ".join([f.origin for f in flights] + [flights[-1].destination])
        tk.Label(card, text=route, font=("Segoe UI", 11), bg="white").pack(anchor="w", pady=3)


    def _seed_sample_data(self):
        t = datetime(2025, 8, 15)

        def add(o, d, dh, ah, p, seats, peak=False, air=None):
            self.graph.add_flight(Flight(
                o, d, t.replace(hour=dh), t.replace(hour=ah),
                p, seats, peak, air or random.choice([a[0] for a in AIRLINES])
            ))

        add("Mumbai", "Delhi", 6, 8, 5200, 8, True)
        add("Mumbai", "Delhi", 9, 11, 4800, 2)
        add("Mumbai", "Chennai", 7, 9, 3200, 6)
        add("Mumbai", "Bangalore", 6, 8, 2200, 7)
        add("Bangalore", "Delhi", 9, 11, 3600, 5, True)
        add("Chennai", "Delhi", 12, 14, 2500, 3)
        add("Pune", "Mumbai", 5, 6, 900, 10)
        add("Pune", "Delhi", 7, 9, 4200, 1, True)


# -------------------------------------------------
# Run App
# -------------------------------------------------
if __name__ == "__main__":
    root = tk.Tk()
    app = FlightBookingApp(root)
    root.mainloop()
